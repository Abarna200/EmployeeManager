export interface attendance {
    aid: number;
    date: string;
    status: string;
  }