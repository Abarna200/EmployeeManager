export class admin {
    username!: string;
    password!: string;
  }
  