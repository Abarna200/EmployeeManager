export class schedule {
    schId!: number;
    fromdate!: string;
    todate!: string;
    timeline!: string;
  }
  