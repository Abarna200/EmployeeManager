export interface details {
    sid: number;
    month: string;
    salary: number;
  }
  