export class userfull {
    eid!: number;
    name!: string;
    dob!: Date;
    email!: string;
    designation!: string;
    address!: string;
    gender!: string;
    phone!: number;
    passwd!: string;
  }
